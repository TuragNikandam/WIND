///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

import 'package:flutter/material.dart';


class foren_overwiev_card_screen extends StatelessWidget {

@override
Widget build(BuildContext context) {
return Scaffold(
backgroundColor: Color(0xffffffff),
appBar: 
AppBar(
elevation:4,
centerTitle:false,
automaticallyImplyLeading: false,
backgroundColor:Color(0xffffffff),
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.zero,
),
title:Text(
"Forum",
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:18,
color:Color(0xff000000),
),
),
leading: Icon(
Icons.arrow_back,
color:Color(0xff212435),
size:24,
),
actions:[
Icon(Icons.add,color:Color(0xffff5630),size:24),
Padding(
padding:EdgeInsets.fromLTRB(0, 0, 10, 0),
child:Icon(Icons.search,color:Color(0xffff5630),size:24),
),
],
),
body:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children: [
Padding(
padding:EdgeInsets.fromLTRB(10, 10, 0, 10),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Chip(
labelPadding:EdgeInsets.symmetric(vertical: 0,horizontal:4),
label:Text("Trend"), labelStyle: TextStyle( fontSize:14,
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
color:Color(0x688a8989),
),
backgroundColor:Color(0xffffffff),
elevation:0,
shadowColor:Color(0xff808080),
shape: RoundedRectangleBorder(
borderRadius:BorderRadius.circular(16.0),
side: BorderSide(color:Color(0xff8a8989),width:1),
),
),
Padding(
padding:EdgeInsets.fromLTRB(10, 0, 0, 0),
child:Chip(
labelPadding:EdgeInsets.symmetric(vertical: 0,horizontal:4),
label:Text("Außenpolitik"), labelStyle: TextStyle( fontSize:14,
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
color:Color(0x698a8989),
),
backgroundColor:Color(0xffffffff),
elevation:0,
shadowColor:Color(0xff808080),
shape: RoundedRectangleBorder(
borderRadius:BorderRadius.circular(16.0),
side: BorderSide(color:Color(0xff8a8989),width:1),
),
),
),
Padding(
padding:EdgeInsets.fromLTRB(10, 0, 0, 0),
child:Icon(
Icons.more_horiz,
color:Color(0xffff5630),
size:24,
),
),
Padding(
padding:EdgeInsets.fromLTRB(30, 0, 0, 0),
child:Icon(
Icons.settings,
color:Color(0xffff5630),
size:24,
),
),
],),),

Expanded(
flex: 1,
child: 
ListView(
scrollDirection: Axis.vertical,
padding:EdgeInsets.all(8),
shrinkWrap:true,
physics:ClampingScrollPhysics(), 
children:[


Card( 
margin:EdgeInsets.symmetric(vertical: 3,horizontal:0),
color:Color(0xa6ff5630),
shadowColor:Color(0xff000000),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(12.0),
),
child:
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.min,
children:[


Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children: [
Padding(
padding:EdgeInsets.fromLTRB(10, 0, 0, 0),
child:Icon(
Icons.person,
color:Color(0xffffffff),
size:40,
),
),
Padding(
padding:EdgeInsets.fromLTRB(5, 0, 0, 0),
child:Text(
"Admin",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xffffffff),
),
),
),
],),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.fromLTRB(15, 8, 8, 8),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Wie kann die Digitale Infrastruktur in Schulen verbessert werden?",
textAlign: TextAlign.start,
maxLines:10,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xffffffff),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 5, 0, 0),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children:[

Icon(
Icons.question_answer,
color:Color(0xffffffff),
size:16,
),
Padding(
padding:EdgeInsets.fromLTRB(5, 0, 0, 0),
child:Text(
"5",
textAlign: TextAlign.start,
maxLines:2,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:15,
color:Color(0xffffffff),
),
),
),
],),),
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Padding(
padding:EdgeInsets.fromLTRB(0, 8, 0, 0),
child:Text(
"Innenpolitik",
textAlign: TextAlign.start,
maxLines:2,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:11,
color:Color(0xffffffff),
),
),
),
Padding(
padding:EdgeInsets.fromLTRB(10, 8, 0, 0),
child:Text(
"30.06.2023",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:11,
color:Color(0xffffffff),
),
),
),
],),
],),),),
],),
),

Card( 
margin:EdgeInsets.symmetric(vertical: 3,horizontal:0),
color:Color(0xa5ff5630),
shadowColor:Color(0xff000000),
elevation:1,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(12.0),
),
child:
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[


Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children: [
Padding(
padding:EdgeInsets.fromLTRB(10, 0, 0, 0),
child:Icon(
Icons.person,
color:Color(0xffffffff),
size:40,
),
),
Padding(
padding:EdgeInsets.fromLTRB(5, 0, 0, 0),
child:Text(
"Max86",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xffffffff),
),
),
),
],),
Expanded(
flex: 1,
child: Padding(
padding:EdgeInsets.fromLTRB(15, 8, 8, 8),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Wie kann der Klimawandel effektiv bekämpft werden?",
textAlign: TextAlign.start,
maxLines:10,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xffffffff),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 5, 0, 0),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Icon(
Icons.question_answer,
color:Color(0xffffffff),
size:16,
),
Padding(
padding:EdgeInsets.fromLTRB(5, 0, 0, 0),
child:Text(
"10",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:15,
color:Color(0xffffffff),
),
),
),
],),),
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Padding(
padding:EdgeInsets.fromLTRB(0, 8, 0, 0),
child:Text(
"Gesundheit",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:11,
color:Color(0xffffffff),
),
),
),
Padding(
padding:EdgeInsets.fromLTRB(10, 8, 0, 0),
child:Text(
"20.05.2023",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:11,
color:Color(0xffffffff),
),
),
),
],),
],),),),
],),
),
],),),
],),
)
;}
}