///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

import 'package:flutter/material.dart';


class home_screen_with_filter extends StatelessWidget {

@override
Widget build(BuildContext context) {
return Scaffold(
backgroundColor: Color(0xffffffff),
appBar: 
AppBar(
elevation:0,
centerTitle:true,
automaticallyImplyLeading: false,
backgroundColor:Color(0x00ffffff),
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.zero,
),
title:Text(
"News",
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:20,
color:Color(0xff000000),
),
),
leading: Icon(
Icons.menu,
color:Color(0xff000000),
size:24,
),
actions:[
Icon(Icons.search,color:Color(0xffff5630),size:24),
],
),
body:SingleChildScrollView(
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Padding(
padding:EdgeInsets.symmetric(vertical: 16,horizontal:0),
child:SingleChildScrollView(
scrollDirection: Axis.horizontal,
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children:[

Padding(
padding:EdgeInsets.fromLTRB(16, 0, 0, 0),
child:Chip(
labelPadding:EdgeInsets.symmetric(vertical: 0,horizontal:4),
label:Text("Trend"), labelStyle: TextStyle( fontSize:14,
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
color:Color(0x688a8989),
),
backgroundColor:Color(0xffffffff),
elevation:0,
shadowColor:Color(0xff808080),
shape: RoundedRectangleBorder(
borderRadius:BorderRadius.circular(16.0),
side: BorderSide(color:Color(0x688a8989),width:1),
),
),
),
Padding(
padding:EdgeInsets.fromLTRB(5, 0, 0, 0),
child:Chip(
labelPadding:EdgeInsets.symmetric(vertical: 0,horizontal:4),
label:Text("Ukraine"), labelStyle: TextStyle( fontSize:14,
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
color:Color(0x688a8989),
),
backgroundColor:Color(0xffffffff),
elevation:0,
shadowColor:Color(0xff808080),
shape: RoundedRectangleBorder(
borderRadius:BorderRadius.circular(16.0),
side: BorderSide(color:Color(0x688a8989),width:1),
),
),
),
Padding(
padding:EdgeInsets.fromLTRB(5, 0, 0, 0),
child:Chip(
labelPadding:EdgeInsets.symmetric(vertical: 0,horizontal:4),
label:Text("Corona"), labelStyle: TextStyle( fontSize:14,
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
color:Color(0x688a8989),
),
backgroundColor:Color(0xffffffff),
elevation:0,
shadowColor:Color(0xff808080),
shape: RoundedRectangleBorder(
borderRadius:BorderRadius.circular(16.0),
side: BorderSide(color:Color(0x688a8989),width:1),
),
),
),
Padding(
padding:EdgeInsets.fromLTRB(10, 0, 0, 0),
child:Icon(
Icons.more_horiz,
color:Color(0xffff5630),
size:24,
),
),
],),),),
Padding(
padding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Row(
mainAxisAlignment:MainAxisAlignment.end,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Text(
"Filter",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
Padding(
padding:EdgeInsets.fromLTRB(5, 0, 0, 0),
child:Icon(
Icons.settings,
color:Color(0xffff5630),
size:20,
),
),
],),
],),

ListView(
scrollDirection: Axis.vertical,
padding:EdgeInsets.fromLTRB(0, 16, 0, 0),
shrinkWrap:true,
physics:ScrollPhysics(), 
children:[

Padding(
padding:EdgeInsets.fromLTRB(0, 0, 0, 16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children:[

Expanded(
flex: 1,
child: 
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Ukraine",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xffff5630),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 8),
child:Text(
"News #1 Thema Ukraine",
textAlign: TextAlign.start,
maxLines:3,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
),
Text(
"20 Juni 2023",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0x9d858383),
),
),
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Icon(
Icons.visibility,
color:Color(0x72212435),
size:16,
),
Padding(
padding:EdgeInsets.fromLTRB(2, 0, 0, 0),
child:Text(
"5",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0x72000000),
),
),
),
],),
],),),
Padding(
padding:EdgeInsets.fromLTRB(8, 0, 0, 0),
child:ClipRRect(
borderRadius:BorderRadius.circular(12.0),
child:
///***If you have exported images you must have to copy those images in assets/images directory.
Image(
image:AssetImage("assets/images/Flag_of_Ukraine.png"),
height:90,
width:90,
fit:BoxFit.cover,
),
),),
],),),
Padding(
padding:EdgeInsets.fromLTRB(0, 0, 0, 16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children:[

Expanded(
flex: 1,
child: 
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Corona",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xffff5630),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 8),
child:Text(
"News #2 Thema Corona",
textAlign: TextAlign.start,
maxLines:3,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
),
Text(
"19 Juni 2023",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0x9d858383),
),
),
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Icon(
Icons.visibility,
color:Color(0x72212435),
size:16,
),
Padding(
padding:EdgeInsets.fromLTRB(2, 0, 0, 0),
child:Text(
"20",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0x72000000),
),
),
),
],),
],),),
Padding(
padding:EdgeInsets.fromLTRB(8, 0, 0, 0),
child:ClipRRect(
borderRadius:BorderRadius.circular(12.0),
child:
///***If you have exported images you must have to copy those images in assets/images directory.
Image(
image:AssetImage("assets/images/206588.jpeg"),
height:90,
width:90,
fit:BoxFit.cover,
),
),),
],),),
Padding(
padding:EdgeInsets.fromLTRB(0, 0, 0, 16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children:[

Expanded(
flex: 1,
child: 
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Heizungsgesetz",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xffff5630),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 8),
child:Text(
"News #3 Thema Heizungsgesetz",
textAlign: TextAlign.start,
maxLines:3,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
),
Text(
"18 Jan 2023",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0x9d858383),
),
),
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Icon(
Icons.visibility,
color:Color(0x72212435),
size:16,
),
Padding(
padding:EdgeInsets.fromLTRB(2, 0, 0, 0),
child:Text(
"500",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0x74000000),
),
),
),
],),
],),),
Padding(
padding:EdgeInsets.fromLTRB(8, 0, 0, 0),
child:ClipRRect(
borderRadius:BorderRadius.circular(12.0),
child:
///***If you have exported images you must have to copy those images in assets/images directory.
Image(
image:AssetImage("assets/images/31835317-heizung-1dfe.png"),
height:90,
width:90,
fit:BoxFit.cover,
),
),),
],),),
Padding(
padding:EdgeInsets.fromLTRB(0, 0, 0, 16),
child:Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children:[

Expanded(
flex: 1,
child: 
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Text(
"Mindestlohn",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xffff5630),
),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 4, 0, 8),
child:Text(
"News #4 Thema Mindestlohn",
textAlign: TextAlign.start,
maxLines:3,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
),
),
Text(
"28 Dez 2022",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0x9d858383),
),
),
Row(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.center,
mainAxisSize:MainAxisSize.max,
children:[

Icon(
Icons.visibility,
color:Color(0x72212435),
size:16,
),
Padding(
padding:EdgeInsets.fromLTRB(2, 0, 0, 0),
child:Text(
"10",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
fontSize:12,
color:Color(0x73000000),
),
),
),
],),
],),),
Padding(
padding:EdgeInsets.fromLTRB(8, 0, 0, 0),
child:ClipRRect(
borderRadius:BorderRadius.circular(12.0),
child:
///***If you have exported images you must have to copy those images in assets/images directory.
Image(
image:AssetImage("assets/images/euro-mindestlohn-100.png"),
height:90,
width:90,
fit:BoxFit.cover,
),
),),
],),),
],),
],),),
],),),
)
;}
}