///File download from FlutterViz- Drag and drop a tools. For more details visit https://flutterviz.io/

import 'package:flutter/material.dart';


class parteipraeferenz_erstellen_screen extends StatelessWidget {

@override
Widget build(BuildContext context) {
return Scaffold(
backgroundColor: Color(0xffffffff),
body:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Icon(
Icons.arrow_back_ios,
color:Color(0xff212435),
size:20,
),
Container(
margin:EdgeInsets.all(0),
padding:EdgeInsets.all(0),
width:MediaQuery.of(context).size.width,
height:MediaQuery.of(context).size.height,
decoration: BoxDecoration(
color:Color(0x00000000),
shape:BoxShape.rectangle,
borderRadius:BorderRadius.zero,
),
child:
Align(
alignment:Alignment.center,
child:Padding(
padding:EdgeInsets.fromLTRB(16, 0, 16, 16),
child:
Column(
mainAxisAlignment:MainAxisAlignment.start,
crossAxisAlignment:CrossAxisAlignment.start,
mainAxisSize:MainAxisSize.max,
children: [
Padding(
padding:EdgeInsets.fromLTRB(55, 30, 0, 0),
child:///***If you have exported images you must have to copy those images in assets/images directory.
Image(
image:AssetImage("assets/images/380545.png"),
height:100,
width:140,
fit:BoxFit.cover,
),
),
Padding(
padding:EdgeInsets.fromLTRB(40, 30, 0, 0),
child:Text(
"Parteipräferenz",
textAlign: TextAlign.start,
overflow:TextOverflow.clip,
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:24,
color:Color(0xff000000),
),
),
),
Padding(
padding:EdgeInsets.fromLTRB(10, 30, 0, 0),
child:Container(
width:MediaQuery.of(context).size.width,
height:50,
padding:EdgeInsets.symmetric(vertical: 4,horizontal:8),
decoration: BoxDecoration(
color:Color(0xffffffff),
borderRadius:BorderRadius.circular(0),
),
child:DropdownButton(
value:"Parteipräferenz",
items:["Parteipräferenz"].map<DropdownMenuItem<String>>((String value) {
return DropdownMenuItem<String>(
value: value,
child: Text(value),);
}).toList(),style: TextStyle(
color:Color(0xff000000),
fontSize:16,
fontWeight:FontWeight.w400,
fontStyle:FontStyle.normal,
), onChanged: (value){},
icon: Icon(Icons.help),
iconSize:24,
iconEnabledColor:Color(0xff212435),
elevation:8,
isExpanded: true,),
),
),
SwitchListTile(
value:true,
title:Text(
"im Profil anzeigen?",
style:TextStyle(
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
fontSize:14,
color:Color(0xff000000),
),
textAlign:TextAlign.start,
),
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.zero,
),
onChanged:(value){},
tileColor:Color(0x00000000),
activeColor:Color(0xffff5630),
activeTrackColor:Color(0x51ff5630),
controlAffinity:ListTileControlAffinity.trailing,
dense:false,
inactiveThumbColor:Color(0xff9e9e9e),
inactiveTrackColor:Color(0xffe0e0e0),
contentPadding:EdgeInsets.symmetric(vertical: 0,horizontal:16),
selected:false,
selectedTileColor:Color(0x42000000),
),
Padding(
padding:EdgeInsets.fromLTRB(0, 30, 0, 16),
child:MaterialButton(
onPressed:(){},
color:Color(0xffff5630),
elevation:0,
shape:RoundedRectangleBorder(
borderRadius:BorderRadius.circular(12.0),
),
padding:EdgeInsets.all(16),
child:Text("Weiter", style: TextStyle( fontSize:16,
fontWeight:FontWeight.w700,
fontStyle:FontStyle.normal,
),),
textColor:Color(0xffffffff),
height:50,
minWidth:MediaQuery.of(context).size.width,
),
),
],),),),
),
],),
)
;}
}